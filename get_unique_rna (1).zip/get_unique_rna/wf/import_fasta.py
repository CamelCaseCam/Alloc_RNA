

# #Change these lines to match your file names
# FilePath = "./Testing/mouse.1.rna.fna"
# OutputFile = "./Testing/MouseTranscriptome.txt"
# load_from_file(FilePath, OutputFile)